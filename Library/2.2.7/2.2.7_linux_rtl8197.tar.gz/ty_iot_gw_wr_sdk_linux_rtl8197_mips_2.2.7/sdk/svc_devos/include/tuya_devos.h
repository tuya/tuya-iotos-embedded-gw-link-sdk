/**
 * @file tuya_sdk.h
 * @author maht@tuya.com
 * @brief SDK通用流程管理，SDK对象管理模块
 * @version 0.1
 * @date 2019-08-28
 * 
 * @copyright Copyright (c) 2019
 * 
 */

#ifndef __TUYA_DEV_H__
#define __TUYA_DEV_H__


#include "tuya_cloud_com_defs.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    BOOL_T is_ignore_upgrade;

    // TBD
}ty_devos_udf_cfg_t;

typedef struct {
    ty_devos_udf_cfg_t udf_cfg;
}ty_devos_t;

int devos_set_udf_ignore_upgrade(const BOOL_T is_ignore);
BOOL_T devos_get_udf_ignore_upgrade();


#ifdef __cplusplus
}
#endif


#endif
