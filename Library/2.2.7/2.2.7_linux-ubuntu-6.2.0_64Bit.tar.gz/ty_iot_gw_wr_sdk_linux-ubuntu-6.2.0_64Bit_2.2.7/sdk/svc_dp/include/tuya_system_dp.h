/*!
\file tuya_system_dp.h
Copyright(C),2017, 涂鸦科技 www.tuya.comm
*/

#ifndef _TUYA_SYSTEM_DP_H
#define _TUYA_SYSTEM_DP_H

#ifdef __cplusplus
extern "C" {
#endif

#define TY_SYSTEM_DP_MIN            200
#define TY_SYSTEM_DP_IR_CTL         201
#define TY_SYSTEM_DP_STUDY_REPORT   202

#ifdef __cplusplus
}
#endif

#endif  


