/***********************************************************
*  File: smart_frame_api.h
*  Author: wsj
*  Date: 20200901
***********************************************************/
#ifndef _SMART_FRAME_API_H
#define _SMART_FRAME_API_H

#include "gw_intf.h"

#ifdef __cplusplus
    extern "C" {
#endif
/***********************************************************
*  Function: gw_sf_dp_data_get
*  Input:  CHAR_T *id, CHAR_T dp_id
*  Output: none
*  Return: DP_CNTL_S
***********************************************************/
DP_CNTL_S * gw_sf_dp_data_get(IN CONST CHAR_T *id, IN CONST CHAR_T dp_id);

/***********************************************************
*  Function: gw_sf_dp_data_is_equl
*  Input: dp_cmd
*  Output: none
*  Return: bool
***********************************************************/
BOOL_T gw_sf_dp_data_is_equl(IN ty_cJSON *dp_cmd);

/***********************************************************
*  Function: gw_sf_dp_data_get
*  Input:  CHAR_T *id, CHAR_T dp_id
*  Output: none
*  Return: DP_CNTL_S
***********************************************************/
DP_CNTL_S * gw_sf_dp_data_get(IN CONST CHAR_T *id, IN CONST CHAR_T dp_id);

/***********************************************************
*  Function: gw_sf_dp_data_is_equl
*  Input: dp_cmd
*  Output: none
*  Return: bool
***********************************************************/
BOOL_T gw_sf_dp_data_is_equl(IN ty_cJSON *dp_cmd);

/***********************************************************
*  Function: gw_sf_gw_scene_exce
*  Input: grp_id ,sce_id
*  Output: none
*  Return: OPERATE_RET
***********************************************************/
OPERATE_RET gw_sf_gw_scene_exce(IN CONST CHAR_T *grp_id, IN CONST CHAR_T *sce_id);

/* 接收并处理来自mqtt，tcp，本地定时的消息 */
OPERATE_RET gw_sf_send_gw_dev_cmd(IN SF_GW_DEV_CMD_S *gd_cmd);

#ifdef __cplusplus
}
#endif
#endif


