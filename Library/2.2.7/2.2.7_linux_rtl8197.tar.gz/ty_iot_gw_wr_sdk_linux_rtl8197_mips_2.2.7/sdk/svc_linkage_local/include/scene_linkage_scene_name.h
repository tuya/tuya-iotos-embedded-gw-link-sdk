#ifndef _SCENE_LINKAGE_SCENE_NAME_H
    #define _SCENE_LINKAGE_SCENE_NAME_H

#include "tuya_cloud_types.h"
#include "scene_linkage.h"

#ifdef __cplusplus
    extern "C" {
#endif


/***********************************************************
*************************micro define***********************
***********************************************************/
//先放开，如果某些设备资源紧张，使用这个宏关闭
#if defined(SUPPORT_AUDIO_SCENE) && (SUPPORT_AUDIO_SCENE==1)
#define SUPPORT_SCENE_NAME 1
#else
#define SUPPORT_SCENE_NAME 0
#endif

/***********************************************************
*************************variable define********************
***********************************************************/

/***********************************************************
*************************function define********************
***********************************************************/

OPERATE_RET scene_linkage_name_init(VOID);

//检测场景名称是否符合要求
OPERATE_RET scene_linkage_name_check(IN CONST CHAR_T *rule_name);


//添加场景名称到场景id的映射关系
OPERATE_RET scene_linkage_name_add(IN LINKAGE_RULE_TYPE_T linkage_type, IN CONST CHAR_T *rule_name, IN CONST CHAR_T *rule_id);

//删除场景名称到场景id的映射关系 根据场景id
OPERATE_RET scene_linkage_name_del(IN LINKAGE_RULE_TYPE_T linkage_type, IN CONST CHAR_T *rule_id);

//删除全部
OPERATE_RET scene_linkage_name_del_all(IN LINKAGE_RULE_TYPE_T linkage_type);

//根据场景名称，得到场景id
OPERATE_RET scene_linkage_id_get_by_name(IN CONST CHAR_T *rule_name, IN INT_T rule_id_buf_len, OUT CHAR_T *rule_id_buf);


#ifdef __cplusplus
}
#endif
#endif

