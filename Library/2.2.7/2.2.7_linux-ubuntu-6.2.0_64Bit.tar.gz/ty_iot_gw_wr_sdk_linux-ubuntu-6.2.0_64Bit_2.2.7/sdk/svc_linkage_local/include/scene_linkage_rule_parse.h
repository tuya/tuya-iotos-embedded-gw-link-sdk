#ifndef __SCENE_LINKAGE_RULE_PARSE_H
    #define __SCENE_LINKAGE_RULE_PARSE_H

#include "tuya_cloud_types.h"
#include "tuya_cloud_com_defs.h"
#include "uni_hlist.h"
#include "action.h"
#include "condition.h"

#ifdef __cplusplus
	extern "C" {
#endif

typedef struct s_scene_linkage_rule {
    CHAR_T id[RULE_ID_LEN+1];
    INT_T ruleType;
    BYTE_T rule_type_local;	//LINKAGE_RULE_LOCAL or LINKAGE_RULE_LAN
    COND_SET_S *cond_set;
    ACTION_SET_S *action_set;
    VOID *parent;
} SCENE_LINKAGE_RULE_S;

VOID set_check_gw_id(IN BOOL_T check);


OPERATE_RET scene_linkage_parse_rule(IN CONST CHAR_T *sl_str, IN CONST LINKAGE_RULE_TYPE_T rule_type, IN BOOL_T save_scene_name, OUT CHAR_T *rule_id, OUT SCENE_LINKAGE_RULE_S **scene_linkage_out);


#ifdef __cplusplus
}
#endif
#endif

