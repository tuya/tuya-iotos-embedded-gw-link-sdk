/*******************************************************************
*  File: tuya_BASE_UF_FILE_error_code.h
*  Author: auto generate by tuya code gen system
*  Description:this file defined the error code of tuya IOT 
*  Device OS module BASE_UF_FILE, you can change it manully
*  if needed
*  Copyright(C),2018-2020, tuya inc, www.tuya.comm
*******************************************************************/

#ifndef TUYA_BASE_UF_FILE_ERROR_CODE_H
#define TUYA_BASE_UF_FILE_ERROR_CODE_H

#ifdef __cplusplus
extern "C" {
#endif


/****************************************************************************
            the error code marco define for module BASE_UF_FILE 
****************************************************************************/
#define OPRT_BASE_UF_FILE_ERRCODE_MAX_CNT 0



#ifdef __cplusplus
}
#endif
#endif
