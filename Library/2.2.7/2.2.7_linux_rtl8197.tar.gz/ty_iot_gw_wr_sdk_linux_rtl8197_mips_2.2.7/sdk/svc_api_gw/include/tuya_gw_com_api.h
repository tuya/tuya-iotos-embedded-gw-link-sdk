/*
tuya_gw_com_api.h
Copyright(C),2018-2020, 涂鸦科技 www.tuya.comm
*/

#ifndef __TUYA_GW_COM_API_H
#define __TUYA_GW_COM_API_H

#include "tuya_cloud_types.h"
#include "tuya_cloud_com_defs.h"

#if defined(ENABLE_ENGINEER_TO_NORMAL) && (ENABLE_ENGINEER_TO_NORMAL==1)
#include "tuya_cloud_com_defs_engr.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

/***********************************************************
*  Function: tuya_iot_gw_bind_dev_attr
*  Desc:     bind a sub-device to gateway
*  Input:    tp: sub-device type
*  Input:    uddd: sub-device detail type
*  Input:    id: sub-device id
*  Input:    pk: sub-device product key
*  Input:    ver: sub-device version
*  Input:    attr: sub-device mcu versions
*  Input:    attr_num: sub-device mcu versions
*  Return:   OPRT_OK: success  Other: fail
***********************************************************/
#define tuya_iot_gw_bind_user_dev(tp, uddd, id, pk, ver) \
    tuya_iot_gw_bind_dev_attr(tp, 0, uddd, id, pk, ver, NULL, 0, FALSE, NULL)

#define tuya_iot_gw_bind_dev(tp, uddd, id, pk, ver) \
    tuya_iot_gw_bind_dev_attr(tp, uddd, 0, id, pk, ver, NULL, 0, FALSE, NULL)
OPERATE_RET tuya_iot_gw_bind_dev_attr(IN CONST GW_PERMIT_DEV_TP_T tp,IN CONST USER_DEV_DTL_DEF_T uddd, USER_DEV_DTL_DEF_T uddd2,\
                                      IN CONST CHAR_T *id,IN CONST CHAR_T *pk,IN CONST CHAR_T *ver, \
                                      IN CONST GW_ATTACH_ATTR_T *attr,IN CONST UINT_T attr_num, \
                                      IN CONST BOOL_T oem, IN CONST CHAR_T *p_firmwarekey);

/***********************************************************
*  Function: tuya_iot_gw_unbind_dev
*  Desc:     unbind a sub-device from gateway
*  Input:    id: sub-device id
*  Return:   OPRT_OK: success  Other: fail
***********************************************************/
OPERATE_RET tuya_iot_gw_unbind_dev(IN CONST CHAR_T *id);

/***********************************************************
*  Function: tuya_iot_dev_online_stat_update
*  Desc:     update sub-device online state
*  Input:    dev_id: sub-device id
*  Input:    online: online state
*  Input:    is_force: true, force update state, false:the same of status,don't update
*  Return:   OPRT_OK: success  Other: fail
***********************************************************/
#define tuya_iot_dev_online_stat_update(dev_id, online) \
    tuya_iot_dev_online_update(dev_id, online, FALSE)
OPERATE_RET tuya_iot_dev_online_update(IN CONST CHAR_T *dev_id,IN CONST BOOL_T online, IN CONST BOOL_T is_force);

/***********************************************************
*  Function: tuya_iot_sys_mag_hb_init
*  Desc:     enable gateway hearbeat check mechanism.if enabled,
*            gateway will check all the sub-devices every 3000 ms,
*            if sub-device not send a heartbeat to gateway during
*            its heartbeat timeout time. the gateway will make
*            the subdevice offline,and notify user by hb_send_cb
*            for at most 3 times.
*  Input:    hb_send_cb: sub-device_id
*  Return:   OPRT_OK: success  Other: fail
***********************************************************/
#define tuya_iot_sys_mag_hb_init(hb_send_cb) \
    tuya_iot_sys_mag_hb_send_init(hb_send_cb, 1000)
OPERATE_RET tuya_iot_sys_mag_hb_send_init(IN CONST DEV_HEARTBEAT_SEND_CB hb_send_cb, IN CONST UINT_T min_query_interval);

/***********************************************************
DON'T USE, NEW INTERFACE: tuya_iot_set_dev_hb_cfg
***********************************************************/
#define tuya_iot_set_dev_hb_timeout(dev_id, hb_timeout_time) \
    tuya_iot_set_dev_hb_timeout_cfg(dev_id, hb_timeout_time, 2)
OPERATE_RET tuya_iot_set_dev_hb_timeout_cfg(IN CONST CHAR_T *dev_id,IN CONST TIME_S hb_timeout_time, IN CONST UINT_T max_resend_times);


/***********************************************************
*  Function: tuya_iot_set_dev_hb_cfg
*  Desc:     set sub-device heartbeat timeout param.
*            if is_sleep:TRUE, this sub-device
*            will skip the heartbeat check.
*  Input:    devid: sub-device_id
*  Input:    is_sleep: true is lowpower dev.
*  Input:    hb_timeout_time: heartbeat timeout, hb_timeout_time==0xffffffff,always online;if is_sleep==flase, the hb_timeout_time is invaild.
*  Input:    max_resend_times: max resend times, default set is 2, don't modify, if you don't know.
*  Return:   OPRT_OK: success  Other: fail
***********************************************************/
OPERATE_RET tuya_iot_set_dev_hb_cfg(IN CONST CHAR_T *dev_id,IN CONST TIME_S hb_timeout_time, IN CONST UINT_T max_resend_times, BOOL_T is_lowpower);


/***********************************************************
*  Function: tuya_iot_fresh_dev_hb
*  Desc:     gateway recv a sub-device heartbeat info
*  Input:    devid: sub-device_id
*  Return:   OPRT_OK: success  Other: fail
***********************************************************/
OPERATE_RET tuya_iot_fresh_dev_hb(IN CONST CHAR_T *dev_id);

/***********************************************************
*  Function: tuya_iot_set_hb_status
*  Desc:     set heartbeat query status,
*  Input:    is_stop:true:stop query, false:query,default is false.
*  Return:   OPRT_OK: success  Other: fail
***********************************************************/
OPERATE_RET tuya_iot_set_hb_status(IN CONST BOOL_T is_stop);

/***********************************************************
*  Function: tuya_iot_gw_reset_dev
*  Input: id
*  Output: none
*  Return: OPERATE_RET
***********************************************************/
OPERATE_RET tuya_iot_gw_reset_dev(IN CONST CHAR_T *id);

#if defined(ENABLE_SIGMESH) && (ENABLE_SIGMESH==1)
/***********************************************************
*  Function: tuya_iot_sigmesh_get_net_info
*            获取sigmesh网络信息
*  Input: none
*  Output: TY_SIGMESH_NET_INFO_S: net_key, app_key
*  Return: 0:success, other:error
***********************************************************/
OPERATE_RET tuya_iot_sigmesh_get_net_info(INOUT TY_SIGMESH_NET_INFO_S *sigmesh_net_info);

/***********************************************************
*  Function: tuya_iot_sigmesh_get_free_node_list
*            获取sigmesh网络信息
*  Input: node_num, nose_list
*  Output: TY_SIGMESH_NET_INFO_S: net_key, app_key
*  Return: 0:success, other:error
***********************************************************/
OPERATE_RET tuya_iot_sigmesh_get_free_node_list(IN CONST INT_T node_num, INOUT TY_SIGMESH_NODE_LIST_S *node_list);

/***********************************************************
*  Function: tuya_iot_sigmesh_get_source_node
*            获取sigmesh网关侧蓝牙端源nodeid
*  Input: NULL
*  Output: source node id
*  Return: 0:success, other:error
***********************************************************/
OPERATE_RET tuya_iot_sigmesh_get_source_node(USHORT_T *source_node);

/***********************************************************
*  Function: tuya_iot_sigmesh_bind
*            获取sigmesh网络信息
*  Input: node_num, nose_list
*  Output: TY_SIGMESH_NET_INFO_S: net_key, app_key
*  Return: 0:success, other:error
***********************************************************/
OPERATE_RET tuya_iot_sigmesh_bind(IN CONST GW_PERMIT_DEV_TP_T tp,IN CONST USER_DEV_DTL_DEF_T uddd,\
                                      IN CONST CHAR_T *id,IN CONST CHAR_T *pk,IN CONST CHAR_T *ver, \
                                      IN CONST GW_ATTACH_ATTR_T *attr,IN CONST UINT_T attr_num, \
                                      IN CONST BOOL_T oem, IN CONST CHAR_T *p_firmwarekey, \
                                      IN CONST CHAR_T *mac, IN CONST CHAR_T *uuid, IN CONST CHAR_T *dev_key);

/***********************************************************
*  Function: tuya_iot_ble_bind
*            单点蓝牙子设备邦定
*  Input:
*  Output: none
*  Return: 0:success, other:error
***********************************************************/
OPERATE_RET tuya_iot_ble_bind(IN CONST GW_PERMIT_DEV_TP_T tp,IN CONST USER_DEV_DTL_DEF_T uddd,\
                          IN CONST CHAR_T *id,IN CONST CHAR_T *pk,IN CONST CHAR_T *ver, \
                          IN CONST GW_ATTACH_ATTR_T *attr,IN CONST UINT_T attr_num, \
                          IN CONST BOOL_T oem, IN CONST CHAR_T *p_firmwarekey, \
                          IN CONST CHAR_T *mac, IN CONST CHAR_T *uuid);

/***********************************************************
*  Function: tuya_iot_sigmesh_get_auth_key
*  Desc:     Get key1 information interface while gateway 
*            bind devices
*  Input: sigmesh_auth_key
*  Output: TY_SIGMESH_AUTH_KEY: encrypted_auth_key, random
*  Return: 0:success, other:error
***********************************************************/
OPERATE_RET tuya_iot_sigmesh_get_auth_key(IN CONST CHAR_T *uuid,INOUT TY_SIGMESH_AUTH_KEY *sigmesh_auth_key);

/***********************************************************
*  Function: tuya_iot_sigmesh_get_bind_status
*  Desc:  Check sigmesh device bind status
*  Input: uuid: sigmesh device mac
*         encryptedValue: produced by uuid and localKey 
*                         with aes encryption
*  Output: bind_status 
*  Return: 0:success, other:error
***********************************************************/
OPERATE_RET tuya_iot_sigmesh_get_bind_status(IN CONST CHAR_T *uuid,IN CONST CHAR_T *encryptedValue,\
                                                INOUT BOOL_T *bind_status);

/***********************************************************
*  Function: tuya_iot_sig_ble_rept_bind_status
*  Desc:  获取sigmesh ble 设备绑定状态
*  Input: node_id: 设备短地址，sigmesh用云端分配的地址，蓝牙单点用uuid
*         bind_status: TURE:绑定成功，FALSE:绑定失败
*  Return: 0:success, other:error
***********************************************************/
OPERATE_RET tuya_iot_sig_ble_rept_bind_status(IN CONST CHAR_T *node_id,IN BOOL_T bind_status);
#endif
/***********************************************************
*  Function: tuya_iot_grp_sce_exce_sys
*  Input: sync dev triggle group or scene
*  Output: none
*  Return: OPERATE_RET
***********************************************************/
OPERATE_RET tuya_iot_grp_sce_exce_sys(IN CONST CHAR_T *grp_id_str, IN CONST USHORT_T sce_id, IN CONST BYTE_T dp_id);


/***********************************************************
*  Function: tuya_iot_get_one_dev_by_group_scene
*  Input: grp_id, sce_id, index
*  Output: dev_id
*  Return: OPERATE_RET
***********************************************************/
OPERATE_RET tuya_iot_get_one_dev_by_group_scene(IN CONST USHORT_T grp_id, IN CONST USHORT_T sce_id, IN CONST INT_T index, OUT CHAR_T *dev_id);


/***********************************************************
*  Function: tuya_iot_get_one_group_by_dev
*  Input:  index dev_id
*  Output: grp_id, sce_id
*  Return: OPERATE_RET
***********************************************************/
OPERATE_RET tuya_iot_get_one_group_by_dev(OUT USHORT_T *grp_id, OUT USHORT_T *sce_id, IN CONST INT_T index, IN CONST CHAR_T *dev_id);

/***********************************************************
*  Function: tuya_iot_group_scene_del_store_by_grp
*  Input: grp_id
*  Output: none
*  Return: OPERATE_RET
***********************************************************/
OPERATE_RET tuya_iot_group_scene_del_store_by_grp(IN CONST USHORT_T grp_id);

/**
 * @brief 给某个群组添加一个标记
 * 
 * @param grp_id [IN]USHORT_T, 需要添加的组id号
 * @param flag [IN]CHAR_T*, 标记字符串
 * @return OPERATE_RET 操作成功返回OPRT_OK
 */
OPERATE_RET tuya_iot_group_flag_add_store_handle(IN USHORT_T grp_id, IN CHAR_T *flag);

/**
 * @brief 根据组id获取标记列表
 * 
 * @param grp_id [IN]USHORT_T, 组id
 * @param cnt [OUT]INT_T *, 标记个数
 * @return CHAR_T** 标记列表,失败返回NULL
 * 
 * @note 使用结束之后需要使用free_group_flag_list释放
 */
CHAR_T** tuya_iot_get_group_flag_list(IN USHORT_T grp_id, OUT INT_T *cnt);

/**
 * @brief 标记列表指针
 * 
 * @param list [IN]CHAR_T**, 需要释放的标记列表
 * @param cnt [IN]INT_T, 指针数组个数
 */
VOID tuya_iot_free_group_flag_list(IN CHAR_T** list, IN INT_T cnt);

/***********************************************************
*  Function: tuya_iot_push_dev_wakeup_status
*  Input: dev_id: subdevice id
*  Output: none
*  Return: OPERATE_RET
***********************************************************/
OPERATE_RET tuya_iot_push_dev_wakeup_status(IN CONST CHAR_T *dev_id);

/***********************************************************
*  Function: tuya_gw_set_subdev_max_cnt
*  Input: cnt: sub dev max count
*  Output: none
*  Return: BOOL_T
***********************************************************/
BOOL_T tuya_gw_set_subdev_max_cnt(UINT_T cnt);

/***********************************************************
*  Function: tuya_gw_get_subdev_cnt
*  Input: none
*  Output: none
*  Return: sub dev count
***********************************************************/
UINT_T tuya_gw_get_subdev_cnt(VOID);

#ifdef __cplusplus
}
#endif

#endif
