#ifndef __THREAD_HEALTH_CHECK_H__
#define __THREAD_HEALTH_CHECK_H__

#include "tuya_cloud_types.h"

#ifdef __cplusplus
extern "C" {
#endif



VOID thread_health_check_init();


#ifdef __cplusplus
} // extern "C"
#endif

#endif // __THREAD_DUMP_H__

