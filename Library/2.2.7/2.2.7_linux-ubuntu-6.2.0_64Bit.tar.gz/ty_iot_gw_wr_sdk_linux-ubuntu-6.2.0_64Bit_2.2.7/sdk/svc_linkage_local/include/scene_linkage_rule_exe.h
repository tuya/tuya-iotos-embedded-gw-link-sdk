#ifndef __SCENE_LINKAGE_RULE_EXE_H
    #define __SCENE_LINKAGE_RULE_EXE_H

#include "tuya_cloud_types.h"
#include "tuya_cloud_com_defs.h"
#include "uni_hlist.h"
#include "action.h"
#include "condition.h"
#include "scene_linkage_rule_parse.h"

#ifdef __cplusplus
	extern "C" {
#endif





/***********************************************************
*************************variable define********************
***********************************************************/

/***********************************************************
*************************function define********************
***********************************************************/

OPERATE_RET scene_linkage_rule_exe_init(VOID);


#if defined(LOCAL_SCENE) && (LOCAL_SCENE==1)
VOID scene_linkage_scene_exe(CHAR_T *sceneId);
#endif

/***********************************************************
*  Function: dp_condition_detect
*  Input: id
*  Input: dp_cmd
*  Output: none 
*  Return: OPERATE_RET
***********************************************************/
// Note:
// id:means gwid,if(cid == NULL) then gwid is actual cid
// dp_cmd:{"cid":"xxxxxx",dps:{"1":2,"2":"111"}} or {"devid":"xxxxxx",dps:{"1":2,"2":"111"}}

OPERATE_RET dp_condition_detect(IN CONST CHAR_T *id,IN CONST CHAR_T *dp_cmd, IN CONST CHAR_T *gw_id, IN LINKAGE_RULE_TYPE_T rule_type);

OPERATE_RET scene_linkage_parse_and_add_2_mag(IN CONST CHAR_T *sl_str);

#if defined(ENABLE_ALARM) && (ENABLE_ALARM==1)
OPERATE_RET secne_linkage_parse_alarm(IN CHAR_T *alarmed_mode, OUT CHAR_T **id_list);
#endif


OPERATE_RET scene_linkage_rule_update_single(SCENE_LINKAGE_RULE_S *linkgae, IN LINKAGE_RULE_TYPE_T rule_type);
OPERATE_RET scene_linkage_rule_delete_single(IN CONST CHAR_T *rule_id, IN LINKAGE_RULE_TYPE_T rule_type);

OPERATE_RET scene_linkage_rule_update_all(SCENE_LINKAGE_RULE_S **linkgae, USHORT_T linkage_num, IN LINKAGE_RULE_TYPE_T rule_type);
OPERATE_RET scene_linkage_rule_delete_all(IN LINKAGE_RULE_TYPE_T rule_type);
OPERATE_RET scene_linkage_dp_detect(IN CONST CHAR_T *id,IN CONST CHAR_T *dp_cmd, IN CONST CHAR_T *gw_id, IN LINKAGE_RULE_TYPE_T rule_type);


VOID stop_tm_duration_proc(CONDITION_S *cond);
#ifdef __cplusplus
}
#endif
#endif

