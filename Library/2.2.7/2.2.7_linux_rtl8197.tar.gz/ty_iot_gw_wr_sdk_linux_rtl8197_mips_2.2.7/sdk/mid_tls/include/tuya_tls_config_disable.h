#ifndef MBEDTLS_CONFIG_H_TY_DISABLE
#define MBEDTLS_CONFIG_H_TY_DISABLE

#err "TLS is not enable, this file should not be build"

#endif /* MBEDTLS_CONFIG_H_TY_DISABLE */
