#ifndef _SCENE_LINKAGE_DP_DETECT_H
    #define _SCENE_LINKAGE_DP_DETECT_H

#include "tuya_cloud_types.h"
#include "scene_linkage.h"

#ifdef __cplusplus
    extern "C" {
#endif

#ifdef  __SCENE_LINKAGE_DP_DETECT_GLOBALS
    #define __SCENE_LINKAGE_DP_DETECT_EXT
#else
    #define __SCENE_LINKAGE_DP_DETECT_EXT extern
#endif

/***********************************************************
*************************micro define***********************
***********************************************************/

/***********************************************************
*************************variable define********************
***********************************************************/

/***********************************************************
*************************function define********************
***********************************************************/

OPERATE_RET scene_linkage_dp_detect_init(VOID);

OPERATE_RET scene_linkage_dp_add(IN CONST CHAR_T *gw_id, IN CONST CHAR_T *id, IN BYTE_T dp_id, IN LINKAGE_RULE_TYPE_T rule_type);

//OPERATE_RET scene_linkage_dp_del(CHAR_T *id, BYTE_T dp_id, LINKAGE_RULE_TYPE_T rule_type);

OPERATE_RET scene_linkage_dp_del_id(IN CONST CHAR_T *gw_id, IN CONST CHAR_T *id, LINKAGE_RULE_TYPE_T rule_type);

OPERATE_RET scene_linkage_dp_del_all(IN LINKAGE_RULE_TYPE_T rule_type);



#ifdef __cplusplus
}
#endif
#endif

