适用于android交叉编译器
```shell
arm-linux-androideabi-gcc --version
arm-linux-androideabi-gcc (GCC) 4.9.x 20150123 (prerelease)
Copyright (C) 2014 Free Software Foundation, Inc.
This is free software; see the source for copying conditions.  There is NO
warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
```

