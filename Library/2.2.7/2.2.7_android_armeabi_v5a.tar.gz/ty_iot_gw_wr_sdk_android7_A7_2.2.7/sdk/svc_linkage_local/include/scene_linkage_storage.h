#ifndef _SCENE_LINKAGE_STORAGE_H
    #define _SCENE_LINKAGE_STORAGE_H

#include "tuya_cloud_types.h"
#include "scene_linkage.h"
#include "rcd_storage.h"

#ifdef __cplusplus
    extern "C" {
#endif

#ifdef  __SCENE_LINKAGE_STORAGE_GLOBALS
    #define __SCENE_LINKAGE_STORAGE_EXT
#else
    #define __SCENE_LINKAGE_STORAGE_EXT extern
#endif

/***********************************************************
*************************micro define***********************
***********************************************************/

/***********************************************************
*************************variable define********************
***********************************************************/

/***********************************************************
*************************function define********************
***********************************************************/

typedef OPERATE_RET (*LINKAGE_READ_ALL_CB)(IN CONST CHAR_T *rule_id, IN CONST CHAR_T *rule_value, VOID *param);

typedef struct tagLinkageStorageMeta{
    UINT_T cnt;			//云端返回的最大的记录个数，仅仅用于拉取时的区间和判断是否修改
    UINT_T real_cnt;	//实际上存储的记录调试
    INT_T last_time;	//最新的时间戳
} LINKAGE_STORAGE_META_S;


//设置当新版本升级后， 是否需要保留老的联动规则的内容（使用kvfile db存储，非rcd的版本）
//默认是false，工程模式下要求是true
//需要在init之前调用
__SCENE_LINKAGE_STORAGE_EXT \
OPERATE_RET scene_linkage_storage_set_reserve_old(BOOL_T b_reserve);

__SCENE_LINKAGE_STORAGE_EXT \
OPERATE_RET scene_linkage_storage_init();

__SCENE_LINKAGE_STORAGE_EXT \
OPERATE_RET  scene_linkage_storage_get_meta(IN LINKAGE_RULE_TYPE_T linkage_type, OUT LINKAGE_STORAGE_META_S *meta);

__SCENE_LINKAGE_STORAGE_EXT \
OPERATE_RET  scene_linkage_storage_set_meta(IN LINKAGE_RULE_TYPE_T linkage_type, IN LINKAGE_STORAGE_META_S *meta, IN BOOL_T flush);

__SCENE_LINKAGE_STORAGE_EXT \
OPERATE_RET  scene_linkage_storage_read(IN LINKAGE_RULE_TYPE_T linkage_type, IN CONST CHAR_T *rule_id, OUT CHAR_T **rule_value);


//注意： LINKAGE_READ_ALL_CB 里面不允许调用本模块函数，否则会死锁
__SCENE_LINKAGE_STORAGE_EXT \
OPERATE_RET  scene_linkage_storage_read_all(IN LINKAGE_RULE_TYPE_T linkage_type, IN LINKAGE_READ_ALL_CB read_cb, VOID *param);

__SCENE_LINKAGE_STORAGE_EXT \
OPERATE_RET  scene_linkage_storage_is_exist(IN LINKAGE_RULE_TYPE_T linkage_type, IN CONST CHAR_T *rule_id);

__SCENE_LINKAGE_STORAGE_EXT \
OPERATE_RET  scene_linkage_storage_get_cnt(IN LINKAGE_RULE_TYPE_T linkage_type, OUT UINT_T *num);

__SCENE_LINKAGE_STORAGE_EXT \
OPERATE_RET  scene_linkage_storage_write(IN LINKAGE_RULE_TYPE_T linkage_type, IN CONST CHAR_T *rule_id, IN CONST CHAR_T *rule_value);

__SCENE_LINKAGE_STORAGE_EXT \
OPERATE_RET  scene_linkage_storage_remove(IN LINKAGE_RULE_TYPE_T linkage_type, IN CONST CHAR_T *rule_id);

__SCENE_LINKAGE_STORAGE_EXT \
OPERATE_RET  scene_linkage_storage_remove_all(IN LINKAGE_RULE_TYPE_T linkage_type);



#ifdef __cplusplus
}
#endif
#endif

