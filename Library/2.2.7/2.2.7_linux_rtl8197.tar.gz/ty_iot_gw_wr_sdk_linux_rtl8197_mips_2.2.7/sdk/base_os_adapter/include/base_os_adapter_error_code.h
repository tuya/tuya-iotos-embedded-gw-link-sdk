/*******************************************************************
*  File: base_os_adapter_error_def.h
*  Author: auto generate by tuya code gen system
*  Date: 2019-08-14
*  Description:this file defined the error code of tuya IOT 
*  Device OS module OS_ADAPTER, you can change it manully
*  if needed
*  Copyright(C),2018-2020, tuya inc, www.tuya.comm
*******************************************************************/

#ifndef BASE_OS_ADAPTER_ERROR_CODE_H
#define BASE_OS_ADAPTER_ERROR_CODE_H

#include "tuya_hal_output.h"

#ifdef __cplusplus
extern "C" {
#endif

#define HAL_LOG_OUTPUT(fmt,...) \
	do{\
		char buf[1024] = {0};\
		snprintf(buf, 1023, fmt, ##__VA_ARGS__);\
		tuya_hal_output_log(buf);\
		}while(0)


/****************************************************************************
            the error code marco define for module OS_ADAPTER 
****************************************************************************/
#define OPRT_OS_REG_NULL_ERROR  -200


#define OS_ADAPTER_CALL_ERR_RETURN_VAL(func, y)\
do{\
    rt = (func);\
    if (OPRT_OK != (rt)){\
        HAL_LOG_OUTPUT("[%s:%d] call %s return %d\n", __FILE__, __LINE__, #func, rt);\
        return (y);\
    }\
}while(0)


#define OS_ADAPTER_CALL_ERR_RETURN(func)\
do{\
    rt = (func);\
    if (OPRT_OK != (rt)){\
       HAL_LOG_OUTPUT("[%s:%d] call %s return %d\n", __FILE__, __LINE__, #func, rt);\
       return (rt);\
    }\
}while(0)


#define OS_ADAPTER_CALL_ERR_GOTO(func, label)\
do{\
    rt = (func);\
    if (OPRT_OK != (rt)){\
        HAL_LOG_OUTPUT("[%s:%d] call %s return %d\n", __FILE__, __LINE__, #func, rt);\
        goto (label);\
    }\
}while(0)


#define OS_ADAPTER_CALL_ERR_LOG(func)\
do{\
    rt = (func);\
    if (OPRT_OK != (rt))\
        HAL_LOG_OUTPUT("[%s:%d] call %s return %d\n", __FILE__, __LINE__, #func, rt);\
}while(0)


#define OS_ADAPTER_CHECK_NULL_RETURN(x, y)\
do{\
    if (NULL == (x))\
        return (y);\
}while(0)


#ifdef __cplusplus
}
#endif
#endif
