#ifndef __TUYA_GW_BASE_UTILITIES_H__
#define __TUYA_GW_BASE_UTILITIES_H__

#include "tuya_gw_base_safe_malloc.h"
#include "tuya_gw_global_errcode.h"

#ifdef __cplusplus
    extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif //!__TUYA_GW_BASE_UTILITIES_H__