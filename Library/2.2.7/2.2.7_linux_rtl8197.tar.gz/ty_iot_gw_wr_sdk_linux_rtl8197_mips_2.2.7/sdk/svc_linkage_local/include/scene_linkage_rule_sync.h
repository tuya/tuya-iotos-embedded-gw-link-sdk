#ifndef _SCENE_LINKAGE_RULE_SYNC_H
    #define _SCENE_LINKAGE_RULE_SYNC_H

#include "tuya_cloud_types.h"
#include "scene_linkage.h"

#ifdef __cplusplus
    extern "C" {
#endif

#ifdef  __SCENE_LINKAGE_RULE_SYNC_GLOBALS
    #define __SCENE_LINKAGE_RULE_SYNC_EXT
#else
    #define __SCENE_LINKAGE_RULE_SYNC_EXT extern
#endif

/***********************************************************
*************************micro define***********************
***********************************************************/

/***********************************************************
*************************variable define********************
***********************************************************/

/***********************************************************
*************************function define********************
***********************************************************/

OPERATE_RET scene_linkage_rule_sync_init(VOID);

VOID reset_scene_info_to_disk(LINKAGE_RULE_TYPE_T rule_type);

BOOL_T check_modify_time_changed(LINKAGE_RULE_TYPE_T rule_type, INT_T input_last_mod_time);

VOID load_scene_info_from_disk(LINKAGE_RULE_TYPE_T rule_type);

OPERATE_RET scene_linkage_update_from_engr(LINKAGE_RULE_TYPE_T linkage_type, INT_T total_cnt, INT_T sl_last_mod_time, ty_cJSON *rules);

#ifdef __cplusplus
}
#endif
#endif

